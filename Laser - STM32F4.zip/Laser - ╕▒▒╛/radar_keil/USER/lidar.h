#include "stm32f4xx.h"
typedef unsigned char uchar;
void pillar_filter(float **block_mid,float **pillar);
void robot_location(float **pillar);
void DisposeData(void);
void block_record(u32 *Distance,float **block_mid);
void roadblock_len_filter(void);
void radar_calculate(uchar*tcp_client_recvbuf,u32 *Distance,float*angle);
void robot_location_6pitch(float **pillar);
void NamePillarAndLocation(float **pillarNow);
void classification(float **pillar);
