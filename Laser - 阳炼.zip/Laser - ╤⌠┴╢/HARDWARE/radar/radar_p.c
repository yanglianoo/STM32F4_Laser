#include"radar_p.h"
#include "usart.h"
void XYtoSitaP(point2f src,float *p,float *sita)
{
	float r=clacLength(src);
	*p=r;
	if(r==0)
	{
		*sita=0;
		return ;
	}
	if(src.y>=0)
	{
		*sita=acos(src.x/r);
	}
	else
		*sita=-acos(src.x/r);
}
float absF(float k)
{
	float s;
	s=k;
    return s>0?s:-s;
}
float absAngle(float  k)
{
	float s;
	s=k;
	if(s<0)
		s=-s;
	if(s>3.14)
		s=s-((int)(s/(3.14))*3.14);
	return s;
}
int isFloat(float s)
{
    if(s>-FLT_MAX/2 && s<FLT_MAX/2)
        return 1;
    else
        return 0;
}
int zuixiaoerchengfa(point2f* src,int inum,line* dst)
{
    float aver_x=0,aver_y=0;
		int i;
	  double sum_xy=0,sum_xx=0;
		float b;
		float a;
    for(i=0;i<inum;i++)
    {
        aver_x+=src[i].x;
        aver_y+=src[i].y;
    }
    aver_x/=inum;
    aver_y/=inum;

    for(i=0;i<inum;i++)
    {
        sum_xy+=src[i].x*src[i].y;
        sum_xx+=src[i].x*src[i].x;
    }
    if(sum_xx-inum*aver_x*aver_x<1e-1)
    {
        //cout<<sum_xx-inum*aver_x*aver_x<<"error"<<endl;
        return 0;
    }
    b=(sum_xy-inum*aver_x*aver_y)/(sum_xx-inum*aver_x*aver_x);

    a=aver_y-b*aver_x;
    dst->b=a;
    dst->k=b;
    return 1;
}
float pointDistanceLine(point2f p,line l)
{
    return absF(l.k*p.x-p.y+l.b)/sqrt(1+l.k*l.k);
}

int findLine(point2f* src,int inum,line_point* dst,int *onum,int minLength,int nihedian,int e)
{
	  int i=0;
	  *onum=0;
    for(i=0;i<inum-nihedian;)
    {
        line temp;
        int begin=i;
        dst[*onum].p1.x=src[i].x;
        dst[*onum].p1.y=src[i].y;
        //dst[*onum].p1.angle=src[i].angle;
        if(!zuixiaoerchengfa(src+i,nihedian,&temp))
        {
            i++;
            continue;
        }
       /* cv::Point p1;
        p1.x=0;
        p1.y=temp.b;
        cv::Point p2;
        p2.x=1000;
        p2.y=temp.k*1000+temp.b;*/

        //cv::line(dst1,p1,p2,cv::Scalar(0,255,255),1);
        while(++i<inum-1 && pointDistanceLine(src[i],temp)<e);
        //cout<<pointDistanceLine(src[i],temp)<<endl;
        //cout<<"***"<<pointDistanceLine(src[i],temp)<<endl;
        dst[*onum].p2.x=src[i].x;
        dst[*onum].p2.y=src[i].y;
        //dst[*onum].p2.angle=src[i].angle;
        if(i-begin<minLength)
            continue;
        (*onum)++;
        /*if(*onum>1)
            break;*/
    }
    //cout<<*onum<<endl;
    return 1;
}

void radar_calculate_p(uchar*tcp_client_recvbuf,u32 *Distance,float*angle)
{
    u16 i=23,j=1;
    u32 distance1,distance2,distance3;
    int index=0;
    if(tcp_client_recvbuf[0]=='G'&&tcp_client_recvbuf[1]=='D')
    {
        for(i=23;i<=1137;i+=3)    //100->333
        {
            if((i-21)%66!=0)
            { distance1=tcp_client_recvbuf[i]-48; //printf("�����Ӧ��ASCII�룺%c",tcp_client_recvbuf[i]);
            }
          else
            { distance1=tcp_client_recvbuf[i+2]-48;  //printf("%c",tcp_client_recvbuf[i+2]);
            i+=2; }
            if((i+1-21)%66!=0)
            { distance2=tcp_client_recvbuf[i+1]-48; //printf("%c",tcp_client_recvbuf[i+1]);
            }
          else
            { distance2=tcp_client_recvbuf[i+3]-48;//printf("%c",tcp_client_recvbuf[i+3]);
            i+=2;}
            if((i+2-21)%66!=0)
            {distance3=tcp_client_recvbuf[i+2]-48; //printf("%c\r\n",tcp_client_recvbuf[i+2]);
            }
          else
            { distance3=tcp_client_recvbuf[i+4]-48; //printf("%c\r\n",tcp_client_recvbuf[i+4]);
            i+=2; }
            Distance[index]=distance1*4096+distance2*64+distance3;//mm
            angle[index]=0.25*(j-1);
            index++;
            j++;
        }
    }
}

float getDistance(point2f p1,point2f p2)
{
    return sqrt((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y));
}
float clacLength(point2f p1)
{
    return sqrt(p1.x*p1.x+p1.y*p1.y);
}

int findPillar(point2f *src,int inum,point2f *dst,int* onum,int d,int min,int max)
{
	  int i=0;
	  int begin;
	  *onum=0;
    for(i=1;i<inum;)
    {

        int length=clacLength(src[i-1]);
        //cout<<i<<" "<<length<<" "<<min<<endl;
        if(length<min || length>max)
        {
            i++;
            continue;
        }

        begin=i-1;

        while(i<inum && getDistance(src[i-1],src[i])<d)
        {
            //cout<<getDistance(src[i-1],src[i])<<endl;
            i++;
        }
        /*if(i<=begin+1)
        {
            i++;
            continue;
        }*/
					i--;
        /*for(int j=begin;j<=i;j++)
            cout<<"***x"<<src[j].x<<" y "<<src[j].y<<endl;*/
        if(getDistance(src[begin],src[i])<d)
           {
            dst[((*onum))].x=src[(i+begin)/2].x;
            dst[((*onum))].y=src[(i+begin)/2].y;
            //dst[((*onum))].angle=src[(i+begin)/2].angle;
            (*onum)++;
            i+=2;
           }
        else
            i+=2;
    }
		return 1;
}

void filterPillar(point2f* src,int inum, point2f p1,point2f p2,float p_dis_e,float p_angle_e,int dis,int e,point2f_2 *dst,int* onum)
{
	int i,j;

	float r1;
	float angle1;
	float r2;
	float angle2;
	
	float temp_r;
	float temp_angle;
	
	float r_dis_max1;
	float r_dis_min1;
	float r_dis_max2;
	float r_dis_min2;
	float sita_max1;
	float sita_min1;
	float sita_max2;
	float sita_min2;
	
	point2f p1_max;
	point2f p1_min;
	
	point2f p2_max;
	point2f p2_min;
	
	*onum=0;
	
	XYtoSitaP(p1,&r1,&angle1);
	XYtoSitaP(p2,&r2,&angle2);
	
	r_dis_max1=r1+p_dis_e/2;
	r_dis_max2=r2+p_dis_e/2;
	
	r_dis_min1=r1-p_dis_e/2;
	r_dis_min2=r2-p_dis_e/2;
	
	sita_max1=angle1+p_angle_e/2;
	sita_min1=angle1-p_angle_e/2;
	
	sita_max2=angle2+p_angle_e/2;
	sita_min2=angle2-p_angle_e/2;
	
	p1_max.x=r1*cos(sita_max1);
	p1_max.y=r1*sin(sita_max1);
	
	p2_max.x=r2*cos(sita_max2);
	p2_max.y=r2*sin(sita_max2);
	
	p1_min.x=r1*cos(sita_min1);
	p1_min.y=r1*sin(sita_min1);
	
	p2_min.x=r2*cos(sita_min2);
	p2_min.y=r2*sin(sita_min2);
	
	for(i=0;i<inum;i++)
	{
		/*if(getDistance(src[i],p1_max)>p_dis_e && getDistance(src[i],p2_max)>p_dis_e && 
			getDistance(src[i],p1_min)>p_dis_e && getDistance(src[i],p2_min)>p_dis_e )
		{printf("���ڱ߽�����\r\n�߽�X:%f y:%f, x:%f y:%f x:%f y:%f x:%f y:%f",p1_max.x,p1_max.y,p1_min.x,p1_min.y,p2_max.x,p2_max.y,p2_min.x,p2_min.y);}
		if((!isInSector(src[i],r_dis_min1,r_dis_max1,sita_min1,sita_max1)) && (!isInSector(src[i],r_dis_min2,r_dis_max2,sita_min2,sita_max2)))
			printf("����������������\r\n");
		else
			printf("��������������\r\n");*/
		if (getDistance(src[i], p1_max)>p_dis_e/2 && getDistance(src[i], p2_max)>p_dis_e/2 &&
			getDistance(src[i], p1_min)>p_dis_e/2 && getDistance(src[i], p2_min)>p_dis_e/2 &&
			(!isInSector(src[i], r_dis_min1, r_dis_max1, sita_min1, sita_max1)) && (!isInSector(src[i], r_dis_min2, r_dis_max2, sita_min2, sita_max2)))
			continue;
		for (j = i + 1;j<inum;j++)
		{
			if (getDistance(src[j], p1_max)>p_dis_e/2 && getDistance(src[j], p2_max)>p_dis_e/2 &&
				getDistance(src[j], p1_min)>p_dis_e/2 && getDistance(src[j], p2_min)>p_dis_e/2 &&
				(!isInSector(src[j], r_dis_min1, r_dis_max1, sita_min1, sita_max1)) && (!isInSector(src[j], r_dis_min2, r_dis_max2, sita_min2, sita_max2)))
				continue;

			if (getDistance(src[i], src[j])<dis + e && getDistance(src[i], src[j])>dis - e)
			{
				dst[*onum].p1 = src[i];
				dst[*onum].p2 = src[j];
				(*onum)++;

			}
		}
		
	}
}

int isInSector(point2f src,float r_min,float r_max,float angle_min,float angle_max)
{
	float r;
	float sita;
	XYtoSitaP(src,&r,&sita);
	if(r<r_min)
		return 0;
	if(r>r_max)
		return 0;
	
	angle_min-=((int)(angle_min/(3.14*2)))*3.14*2;
	angle_max-=((int)(angle_max/(3.14*2)))*3.14*2;
	if(angle_min<0)
		angle_min+=2*3.141;
	if(angle_max<0)
		angle_max+=2*3.141;
	if(sita<0)
		sita+=2*3.141;

if (angle_min == angle_max)
		return 1;
	if (angle_min > angle_max)
	{
		if (sita >= angle_min && sita <= 3.14159*2)return 1;
		if (sita > 0 && sita <= angle_max)return 1;
		return 0;
	}
	if (sita>angle_min && sita<angle_max)
		return 1;
	else
		return 0;
}

void clacRadarPillar(point2f world_p1,point2f world_p2,point2f world_location,float world_angle,point2f* p1,point2f *p2)
{
	world_p1.x-=world_location.x;
	world_p1.y-=world_location.y;
	world_p2.x-=world_location.x;
	world_p2.y-=world_location.y;
	p1->x=world_p1.x*cos(-world_angle)-world_p1.y*sin(-world_angle);
	p1->y=world_p1.x*sin(-world_angle)+world_p1.y*cos(-world_angle);
	
	p2->x=world_p2.x*cos(-world_angle)-world_p2.y*sin(-world_angle);
	p2->y=world_p2.x*sin(-world_angle)+world_p2.y*cos(-world_angle);
	
}
int clacLocation(point2f_2* src,int inum,point2f lastXY,float angle,float disE,float angleE,point2f*output,float *oAngle,point2f p1,point2f p2,point2f o)
{
	int i=0;
	point2f tempP;
	float tempA;
	//float minAngle=-1;
	float minDis=-1;
	for(i=0;i<inum;i++)
	{
		solveTriangle(src[i].p1,src[i].p2,o,&tempP,&tempA,p1,p2);
		if(getDistance(lastXY,tempP)<disE /*&& absAngle(tempA-angle)<angleE*/   )
		{
			if(minDis==-1)
			{ 
				minDis=getDistance(tempP,lastXY);
				output->x=tempP.x;
				output->y=tempP.y;
				*oAngle=tempA;
				//printf("��̾���:%f\r\n",getDistance(src[i].p1,src[i].p2));
			}
			else
			{
				if(getDistance(tempP,lastXY)<minDis)
			{
				output->x=tempP.x;
				output->y=tempP.y;
				*oAngle=tempA;
				//minAngle=absAngle(tempA-angle);
				minDis=getDistance(tempP,lastXY);
				//printf("��̾���:%f\r\n",getDistance(src[i].p1,src[i].p2));
			}
			}				
			/*if(minAngle==-1)
			{
				minAngle=absAngle(tempA-angle);
				output->x=tempP.x;
				output->y=tempP.y;
				*oAngle=tempA;
			}
			else
			{
				if(absAngle(tempA-angle)<minAngle)
			{
				output->x=tempP.x;
				output->y=tempP.y;
				*oAngle=tempA;
				minAngle=absAngle(tempA-angle);
			}
		  }*/
			//return 1;
			//printf("sum:%d now:%d x:%f y:%f  x:%f y:%f\r\n",inum,i,src[i].p1.x,src[i].p1.y,src[i].p2.x,src[i].p2.y);
		}
		//printf("angle:%f\r\n",tempA/3.14*180);
		//printf("sum:%d now:%d x:%f y:%f  x:%f y:%f\r\n",inum,i,src[i].p1.x,src[i].p1.y,src[i].p2.x,src[i].p2.y);
		solveTriangle(src[i].p2,src[i].p1,o,&tempP,&tempA,p1,p2);
			if(minDis==-1)
			{
				minDis=getDistance(tempP,lastXY);
				output->x=tempP.x;
				output->y=tempP.y;
				*oAngle=tempA;
				//printf("��̾���:%f\r\n",getDistance(src[i].p1,src[i].p2));
			}
			else
			{
				if(getDistance(tempP,lastXY)<minDis)
			{
				output->x=tempP.x;
				output->y=tempP.y;
				*oAngle=tempA;
				//minAngle=absAngle(tempA-angle);
				minDis=getDistance(tempP,lastXY);
			//	printf("��̾���:%f\r\n",getDistance(src[i].p1,src[i].p2));
			}
			}			
			//printf("sum:%d now:%d x:%f y:%f  x:%f y:%f\r\n",inum,i,src[i].p2.x,src[i].p2.y,src[i].p1.x,src[i].p1.y);
		//printf("sum:%d now:%d x:%f y:%f  x:%f y:%f\r\n",inum,i,src[i].p2.x,src[i].p2.y,src[i].p1.x,src[i].p1.y);
		//printf("angle:%f\r\n",tempA/3.14*180);
	}
	//printf("***%f\r\n",minAngle/3.14*180.0)
//	printf("��̾���:end\r\n");
	if(minDis!=-1)
		return 1;
	else
		return 0;
}
int solveTriangle(point2f p1,point2f p2,point2f o,point2f *result,float *angle,point2f real_p1,point2f real_p2)
{
    point2f real;
	  point2f p;
	  point2f op1;
	  float real_length;
    float p_length;
    float s_length;

    float dx;
    float dy;
    float cosTheta;
    float Theta;
    float sinTheta;
    float cross;
    float Theta2;
    real.x=real_p2.x-real_p1.x;
    real.y=real_p2.y-real_p1.y;
    p.x=p2.x-p1.x;
    p.y=p2.y-p1.y;

   
    op1.x=o.x-p1.x;
    op1.y=o.y-p1.y;
    real_length=getDistance(real_p1,real_p2);
    p_length=getDistance(p1,p2);
    s_length=real_length/p_length;

    dx=real_p1.x-p1.x;
    dy=real_p1.y-p1.y;
    cosTheta=(p.x*real.x+p.y*real.y)/(clacLength(real)*clacLength(p));
    Theta=acos(cosTheta);
    sinTheta=sin(Theta);
    cross=p.x*real.y-real.x*p.y;//p*real ?????p?real??????
    Theta2=0;
    if(cross<0)
    {
        //cout<<"********"<<endl;
        sinTheta=-sinTheta;
        Theta=-Theta;
    }
   /* if(real.y>=0)
        Theta2=acos(real.x/clacLength(real));
    else
        Theta2=-acos(real.x/clacLength(real));
		*/

    //cout<<"****data****"<<endl;

    //o.x=o.x-p1.x;
    //o.y=o.y-p1.y;

    o.x=p1.x+(o.x-p1.x)*s_length;
    o.y=p1.y+(o.y-p1.y)*s_length;

    o.x-=p1.x;
    o.y-=p1.y;

    result->x=o.x*cosTheta-sinTheta*o.y+dx;
    result->y=o.x*sinTheta+cosTheta*o.y+dy;

    result->x+=p1.x;
    result->y+=p1.y;
		
    *angle=Theta;
		if((*angle)>3.141)
			*angle=*angle-3.14*2;
		if((*angle)<-3.141)
			*angle=*angle+3.14*2;
    //result->x=o.x*sx*cosTheta-sinTheta
    //*sy*o.y+cosTheta*dx-sinTheta*dy;
    //result->y=o.x*sx*sinTheta+o.y*cosTheta*sy+sinTheta*dx+cosTheta*dy;




    return 1;
}
