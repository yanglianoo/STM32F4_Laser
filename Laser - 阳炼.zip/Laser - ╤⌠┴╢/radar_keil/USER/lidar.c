#include "sys.h"
#include "tcp_client_demo.h"
#include "delay.h"
#include "math.h"
#include "string.h"
//#include "can1.h"
#include "lidar.h"
#include "led.h"
#include "malloc.h"


#define PI 3.1415926

void block_dist_filter(void);
float PILLARA[2][2] = { 1225,2000 };
float PILLARB[2][2] = { 1225,3500 };
float PILLARC[2][2] = { 1225,5000 };
float PILLARa[2][2] = { 12075,3500 };
float PILLARb[2][2] = { 12075,3500 };
float PILLARc[2][2] = { 12075,3500 };
float	  mr2_x[4] = { 0 };//ǰ��λ������¼ͨ��ABC�������ֵ������λ������¼ǰ���ߵ�ƽ��ֵ
float   mr2_y[4] = { 0 };//ǰ��λ������¼ͨ��ABC�������ֵ������λ������¼ǰ���ߵ�ƽ��ֵ
typedef unsigned char uchar;
void radar_calculate(uchar*tcp_client_recvbuf,u32 *Distance,float*angle);
float DistTwoPillar(float **pillar, int pillara, int pillarb);
void findLinePillar(float pillar[][5],float **new_pillar);


//int Distance[1080];//Ϊ���뺯����õĵ�i��step�ľ���ֵ����λΪmm
int	rang = 9000;//�趨ɸѡ��Χ
int	block[1080] = { 30000 };//��������ϰ���step�����飬Ĭ��Ϊ����Զ��30m��
int useful_block[1080] = { 0 };//���������Ч�ϰ���ľ���
int pillar_wid = 63;//����ֱ��Ϊ60mm���ſ�����
int pillar_wid_deviation = 60;//�ж����ӵ����Ϊ10mm
int ALL_STEP = 1080;//�״�step��
float mr2_coordinate[3] = { 0 };//������x��y���꣬��ƫ����
float mr2_coordinate_x=0,mr2_coordinate_y=0;
int x = 0, y = 1, yaw = 2;//��robot_coordinate�������Ӧ��˳��
int pillar_num = 0;
int block_step = 0, block_dist = 1, block_widt = 2;//����ĵ�һ��������¼�ϰ����step���ڶ���������¼���룬������������¼����
int step = 0, dist = 1, group = 2, step_num = 3, name = 4;//��һ�м�¼���ӵ�step���ڶ��м�¼���ӵľ��룬�����м�¼���ӵ���𣬵����м�¼���ӵ�step��
int A = 1, B = 2, C = 3, D = 4, E = 5, F = 6;//����������
//float pillar[2][20] = { 0 };//������¼ɸѡ���ж�Ϊ���ӵ����飬����ĵ�һ��������¼���ӵ�step���ڶ���������¼����
//float block_mid[3][500]={0};//��¼���ӵ��м�step�;��룬Ӧ�Ż���step�;���ĳɶ��������
int AB_MIN = 1440, AB_MAX = 1855, AC_MIN = 3050, AC_MAX = 3220, AD_MIN = 11265, AD_MAX = 11320,
AE_MIN = 10925, AE_MAX = 11015, AF_MIN = 10855, AF_MAX = 10885;
#define pMax 80
void sePillar(float pillarNow[][5], float **pillarNew2);

double p = 0.25*3.14159265359/180.0;

//extern float **block_mid;
int pillarf = 0, pillare = 1, pillard = 2, pillarc = 3, pillarb = 4, pillara = 5;


int block_num = 0;//������¼�ϰ��������

void robot_location_6pitch(float **pillar);

extern u8 recieve[TCP_CLIENT_RX_BUFSIZE];//��tcp_client_demo.c�����������飬���ڴ���״﷢�͹������ַ�������
//extern int Distance[1200];//���ڴ�Ž����ľ������ݣ���λ��mm
u16 distancelen = 0;//

float Abs(float a)
{
	if(a<0)
		return -a;
	return a;
}

void radar_calculate(uchar*tcp_client_recvbuf,u32 *Distance,float*angle)
{
    u16 i=23,j=1;
    u32 distance1,distance2,distance3;
    int index=0;
    if(tcp_client_recvbuf[0]=='G'&&tcp_client_recvbuf[1]=='D')
    {
        for(i=23;i<=3368;i+=3)    //100->333
        {
            if((i-21)%66!=0)
            { distance1=tcp_client_recvbuf[i]-48; //printf("�����Ӧ��ASCII�룺%c",tcp_client_recvbuf[i]);
            }
          else
            { distance1=tcp_client_recvbuf[i+2]-48;  //printf("%c",tcp_client_recvbuf[i+2]);
            i+=2; }
            if((i+1-21)%66!=0)
            { distance2=tcp_client_recvbuf[i+1]-48; //printf("%c",tcp_client_recvbuf[i+1]);
            }
          else
            { distance2=tcp_client_recvbuf[i+3]-48;//printf("%c",tcp_client_recvbuf[i+3]);
            i+=2;}
            if((i+2-21)%66!=0)
            {distance3=tcp_client_recvbuf[i+2]-48; //printf("%c\r\n",tcp_client_recvbuf[i+2]);
            }
          else
            { distance3=tcp_client_recvbuf[i+4]-48; //printf("%c\r\n",tcp_client_recvbuf[i+4]);
            i+=2; }
            Distance[index]=distance1*4096+distance2*64+distance3;//mm
            angle[index]=0.25*(j-1);
            index++;
            j++;
        }
    }
}




//�������Ӽ�ľ���
float DistTwoPillar1(float pillar[][5], int pillara, int pillarb)//�������Ӽ�ľ���,C���Բ���������ͬ�������+1
{
	float a = pillar[pillara][dist], b = pillar[pillarb][dist];
	float Angleab = (Abs(pillar[pillara][step] - pillar[pillarb][step]))*p;
	return sqrt(pow(a, 2) + pow(b, 2) - 2 * a*b*cos(Angleab));
}




//��¼�����ϰ������״�����λ��



void block_record(u32 *Distance,float **block_mid)
{
	//����ѭ���ͼ�¼pillar����Ŀ
	volatile int flag = 0;//�����ж������Ƿ��¼��ȫ��1Ϊ�жϼ�¼��ȫ
	int block_min = 0, block_max = 0;//��¼�ϰ������ʼstep��
  int	i = 1;
	double p = 0.25*3.14159265359/180.0;
	int c=0,dist_min;
	block_num=0;
	for (i = 0; i < ALL_STEP-1; i++)//400;i< 600; i++)//ALL_STEP; i++)//i < 30; i++)//ALL_STEP; i++)
	{
		if (Distance[i] < 6000)//ɸѡ10m�ڵ��ϰ���
		{
			block_min = i, block_max = i;
			flag = 0;
			for (flag = 0; flag == 0; i++)//�������ӵĿ���
			{
				if ( Abs((int)(Distance[i+1] - (int)Distance[i])) < (pillar_wid ) )//�˴�����������Ӧ��ԶС��pillar_wid����Ϊ��������step֮���Ǿ��벻���ܴﵽpillar_wid
				{
					block_max = i+1;
				}
				
				else
				{
					
					flag = 1;//���������ϰ�����ȵ�ѭ��
					block_mid[block_step][block_num] = (block_max + block_min) / 2;
					block_mid[block_dist][block_num] = Distance[(block_max + block_min+1) / 2];//����ֻȡ�м�step�ľ���Ϊ�ϰ���ľ��룬Ӧ�Ż�
					block_mid[block_widt][block_num] = sqrt(pow((double)Distance[block_max],2) +
																									pow((double)Distance[block_min],2) -
																									2*( (double)Distance[block_max] ) *
																									(double)Distance[block_min]* (cos( (double)(block_max-block_min+1) *p)));
					i--;				
					block_num++;
				}
			}
		}
	}
	printf("ʮ������%d���ϰ���\r\n", block_num);
}
void pillar_filter(float **block_mid, float **pillar)
{
	extern int block_num;
	volatile int i = 0;
	int j = 0;
//	float **temp_widt = { 0 };//��ſ��Ⱥ��ʵ��ϰ���
//	float **temp_dist = { 0 };//��ž�����ʵ��ϰ���
	float temp_widt[50][5] = { 0 };//��ſ��Ⱥ��ʵ��ϰ���
	float temp_dist[50][5] = { 0 };//��ž�����ʵ��ϰ���

	int temp_pillar = 0;
	i = 0;
	pillar_num = 0;
	
	for (i = 0; i < 20; i++)
	{
		for (j = 0; j < 5; j++)
		{
			pillar[i][j] = 0;
		}
	}
	


	for (i = 0; i < block_num; i++)//ɸѡ���Ⱥ��ʵ�����,�Ѻ��ʵ��ϰ���ŵ�temp_widt��������
	{
		//		printf("block_mid[dist][%d]:%f block[widt][%d]:%f\r\n",i,block_mid[block_dist][i],i,block_mid[block_widt][i]);
		//if ((block_mid[block_widt][i] > (pillar_wid - 10)) && (block_mid[block_widt][i] < (pillar_wid + pillar_wid_deviation))) //������ȣ�����ϰ����������60+-10mm�Ļ�����Ϊ����
		
		if ((block_mid[block_widt][i] > (58)) && (block_mid[block_widt][i] < (500)))
		{
			temp_widt[temp_pillar][step] = block_mid[block_step][i];
			temp_widt[temp_pillar][dist] = block_mid[block_dist][i];

//			printf("����:%f\t\tsetp:%f\t����:%f\r\n", temp_widt[temp_pillar][dist], temp_widt[temp_pillar][step], block_mid[block_widt][i]);
			temp_pillar++;
		}
	}


	for (i = 0; i < temp_pillar; i++)//ɸѡ����ֵ����Ҫ�������
	{
		for (j = i + 1; j < temp_pillar; j++)
			if (DistTwoPillar1(temp_widt, i, j) > AB_MIN-20 && DistTwoPillar1(temp_widt, i, j) < AB_MAX+20)
			{
				temp_dist[pillar_num][step] = temp_widt[i][step];
				temp_dist[pillar_num][dist] = temp_widt[i][dist];
				temp_dist[++pillar_num][step] = temp_widt[j][step];
				temp_dist[pillar_num][dist] = temp_widt[j][dist];
				pillar_num++;
				i = j;
			}		
	}

	for (i = 0; i < temp_pillar; i++)
	{
		for (j = i + 1; j < temp_pillar; j++)
			if (DistTwoPillar1(temp_widt, i, j) > AC_MIN-20 && DistTwoPillar1(temp_widt, i, j) < AC_MAX+20)
			{
				temp_dist[pillar_num][step] = temp_widt[i][step];
				temp_dist[pillar_num][dist] = temp_widt[i][dist];
				temp_dist[++pillar_num][step] = temp_widt[j][step];
				temp_dist[pillar_num][dist] = temp_widt[j][dist];
				pillar_num++;
				i = j;
			}
	}

	for (i = 0; i < temp_pillar; i++)
	{
		for (j = i + 1; j < temp_pillar; j++)
			if (DistTwoPillar1(temp_widt, i, j) > AD_MIN-20 && DistTwoPillar1(temp_widt, i, j) < AD_MAX+20)
			{
				temp_dist[pillar_num][step] = temp_widt[i][step];
				temp_dist[pillar_num][dist] = temp_widt[i][dist];
				temp_dist[++pillar_num][step] = temp_widt[j][step];
				temp_dist[pillar_num][dist] = temp_widt[j][dist];
				pillar_num++;
				i = j;
			}
	}

	for (i = 0; i < temp_pillar; i++)
	{
		for (j = i + 1; j < temp_pillar; j++)
			if (DistTwoPillar1(temp_widt, i, j) > AE_MIN-20 && DistTwoPillar1(temp_widt, i, j) < AE_MAX+20)
			{
				temp_dist[pillar_num][step] = temp_widt[i][step];
				temp_dist[pillar_num][dist] = temp_widt[i][dist];
				temp_dist[++pillar_num][step] = temp_widt[j][step];
				temp_dist[pillar_num][dist] = temp_widt[j][dist];
				pillar_num++;
				i = j;
			}
	}

	for (i = 0; i < temp_pillar; i++)
	{
		for (j = i + 1; j < temp_pillar; j++)
			if (DistTwoPillar1(temp_widt, i, j) > AF_MIN-20 && DistTwoPillar1(temp_widt, i, j) < AF_MAX+20)
			{
				temp_dist[pillar_num][step] = temp_widt[i][step];
				temp_dist[pillar_num][dist] = temp_widt[i][dist];
				temp_dist[++pillar_num][step] = temp_widt[j][step];
				temp_dist[pillar_num][dist] = temp_widt[j][dist];
				pillar_num++;
				i = j;
			}
	}
	//temp_pillar = pillar_num;

	
	//for (i = 0; i < temp_pillar; i++)
	//{
	//	for (j = i + 1; j < temp_pillar; j++)
	//	{
	//		if (pillar[i][step] == temp[j][step])
	//		{
	//			pillar[j][step] = temp[j + 1][step];
	//			pillar[j][dist] = temp[j + 1][dist];
	//			/*pillar_num++;*/
	//		}
	//	}
	//}
	
	//����ȥ����ͬ������

	for (i = pillar_num; i > 0; i--)//��������Ųһλ
	{
		temp_dist[i][step] = temp_dist[i - 1][step];
		temp_dist[i][dist] = temp_dist[i - 1][dist];
	}
	for (i = 1; i < pillar_num; i++)//ֱ�Ӳ�������
	{
		if (temp_dist[i + 1][step] < temp_dist[i][step] && temp_dist[i][step]!=0)
		{
			temp_dist[0][step] = temp_dist[i + 1][step];
			temp_dist[0][dist] = temp_dist[i + 1][dist];
			j = i + 1;
			do {
				j--;
				temp_dist[j + 1][step] = temp_dist[j][step];
				temp_dist[j + 1][dist] = temp_dist[j][dist];
			} while (temp_dist[0][step] < temp_dist[j - 1][step]);
			temp_dist[j][step] = temp_dist[0][step];
			temp_dist[j][dist] = temp_dist[0][dist];
		}
	}

	for (i = 1; i < pillar_num + 1; i++)//������ǰŲһλ
	{
		temp_dist[i - 1][step] = temp_dist[i][step];
		temp_dist[i - 1][dist] = temp_dist[i][dist];
	}
	temp_dist[pillar_num][step] = 0;
	temp_dist[pillar_num][dist] = 0;

	for (i = 1; i < pillar_num; i++)//ȥ����ͬ������
	{
		j = i;
		if (temp_dist[i][step] == temp_dist[i - 1][step])
		{
			for (; j < pillar_num + 1; j++)//������ǰŲһλ
			{
				temp_dist[j][step] = temp_dist[j + 1][step];
				temp_dist[j][dist] = temp_dist[j + 1][dist];
				
			}
			i--;
			pillar_num--;
		}

	}
	
	
	printf("step:\r\n");
	for(i=0;i<pillar_num;i++)//ɸѡǰ
	{
		printf("%f,",temp_dist[i][step]);
	}
	printf("\r\n");
	printf("dist:\r\n");
	for(i=0;i<pillar_num;i++)//ɸѡǰ
	{
		printf("%f,",temp_dist[i][dist]);
	}
	printf("\r\n");
	
//	sePillar(temp_dist, pillar);
	
	
	findLinePillar(temp_dist, pillar);

	
	//	
//	for (i = 0; i < pillar_num; i++)
//	{
//		pillar[i][step] = temp_dist[i][step];
//		pillar[i][dist] = temp_dist[i][dist];
//	}
//	
	
	printf("ɸѡ�����ӵ������У�%d��\r\n", pillar_num);
	
	
	
	
	
	printf("in one line:%d\r\n",pillar_num);
	printf("in one line:\r\n");
	printf("step:\r\n");
	for(i=0;i<pillar_num;i++)//ɸѡ��
	{
		printf("%f,",pillar[i][step]);
	}
	printf("\r\n");
	printf("dist:\r\n");
	for(i=0;i<pillar_num;i++)//ɸѡ��
	{
		printf("%f,",pillar[i][dist]);
	}
	printf("\r\n");
	
//	
//	for (i = 0; i < pillar_num; i++)//��ӡ����״̬
//		printf("ɸѡ�������:%f\t\tsetp:%f\r\n", pillar[i][dist], pillar[i][step]);

//	for (i = 0; i < pillar_num; i++)
//		printf("%f,", pillar[i][step]);
//	printf("\n");
//	for (i = 0; i < pillar_num; i++)
//		printf("%f,", pillar[i][step]);
//	printf("\r\n");

//	myfree(SRAMEX,temp_dist);
//	myfree(SRAMEX,temp_widt);
}


	//����3���Ƿ���ͬһֱ�ߣ�������5cm�����м��ƫ������������5cm��
	void judge_in_oneline()
	{

	}

#define PI_M 3.14159265359

#define pIndex 0
#define pLen 1
#define pNum 2
#define pGroup 3
#define pName 4

float pillarOld[6][5];

int left_num = 0, right_num = 0;//????????????
#define Left 1
#define Right 2


int LgroupNum;
int RgroupNum;

float lengthThreshold;
float pointThreshold;
float indexTreshold;

float DistTwoPillar(float **pillar, int pillara, int pillarb)//�������Ӽ�ľ���
{
	float a = pillar[pillara][dist], b = pillar[pillarb][dist];
	float Angleab = (Abs(pillar[pillara][step] - pillar[pillarb][step]))*p;
	return sqrt(pow(a, 2) + pow(b, 2) - 2 * a*b*cos(Angleab));
}
float CalculateAngle(float **pillar, int pillara, int pillarb)//�ж������������״�֮��ļн�
{
	return Abs((pillar[pillara][step] - pillar[pillarb][step]))*0.25;
}

int DivideGroup(float **pillar)
{
	float AgLm = 80;//??:? ???????????80?????????
	int i = 1;
	int flag = 0;
	left_num = 0;
	right_num = 1;
	pillar[0][group] = Right;//??????????
	for (; i < pillar_num; i++)
	{
		if (CalculateAngle(pillar, i, i - 1) <= AgLm && flag == 0)
		{
			pillar[i][group] = Right;
			right_num++;
		}
		else
		{
			pillar[i][group] = Left;
			flag = 1;
			left_num++;
		}
	}
	if (flag == 0)
		return 0;//????,?????
	else
		return 1;//flag=1?????,?????????
}

int RightState(float **pillar)
{
	switch (right_num)
	{
	case 3:
		return 3;
	case 2:
		if (DistTwoPillar(pillar, 0, 1) > 2500)//�ж�ǰ�������ӵľ����Ƿ����2500mm������Ϊ�м��
			return 2;
		else
			return 1;
	case 1:
		return 0;
	default:
		return -1;
	}
}

int LeftState(float **pillar)
{
	switch (left_num)
	{
	case 3:
		return 3;
	case 2:
		if (DistTwoPillar(pillar, 0, 1) > 2500)//�ж�ǰ�������ӵľ����Ƿ����2500mm������Ϊ�м��
			return 2;
		else
			return 1;
	case 1:
		return 0;
	default:
		return -1;
	}
}


float lengthThreshold2;

//????
float take_distance(float x1, float y1, float x2, float y2) {
	float deltaX = Abs(x1 - x2);
	float deltaY = Abs(y1 - y2);

	return sqrt(deltaX*deltaX + deltaY * deltaY);
}
//????
float pol2rectX(float len, float angle) {
	return len * cos(angle*PI_M / 180);
}
float pol2rectY(float len, float angle) {
	return len * sin(angle*PI_M / 180);
}



float t_len(float x, float y) {
	return sqrt(x*x + y * y);
}
float t_angle(float vectorX1, float vectorY1, float vectorX2, float vectorY2) {
	float len1, len2;
	float result;
	float result_mul;
	
	len1 = t_len(vectorX1, vectorY1);
	len2 = t_len(vectorX2, vectorY2);
	
	result_mul = vectorX1 * vectorX2 + vectorY1 * vectorY2;
	

	result	= result_mul / (len1*len2);
	return acos(result);

}

void clean_old(float old[][5]) {
	float(*p);
	int j = 0;
	int i = 0;
	//j<6??6?old??????
	for (; j < 6; j++) {

		p = *(old + j);
		for (; i < 4; i++) {
			p[i] = 0;
		}
	}
}

void now2old(float now[][5], float old[][5]) {

	int i = 0;
	clean_old(pillarOld);

	for (; i < pillar_num; i++) {

		if (now[i][4] != 0) {
			old[(int)now[i][4]][0] = now[i][0];
			old[(int)now[i][4]][1] = now[i][1];
			old[(int)now[i][4]][2] = now[i][2];
			old[(int)now[i][4]][3] = now[i][3];
		}

	}
}


void matchFromOld(float now[][5], float old[][5], int index) { //index?now???????

	int r = 2;
	int j = 0;
	int i = 0;
	for (; j < 6; j++) {
		for (; i < pillar_num; i++) {
			//now[i]?????
			//??????????????
			if (now[i][4] != 0)
				break;
			if (old[j][2] + r > now[i][2] && old[j][2] + r < now[i][2]) {
				now[i][4] = old[j][4];
				break;
			}
		}
	}

}

void InitPillarName()
{
	pillara=-1;
	pillarb=-1;
	pillarc=-1;
	pillard=-1;
	pillare=-1;
	pillarf=-1;
}

void NamePillarAndLocation(float **pillarNow) //����������
{
	float x1, y1;
	float x2, y2;
	float x3, y3;
	float vx1, vy1;
	float vx2, vy2;
	float vx3, vy3;

	float angle1, angle2;

	int group_finded;
	//int finePillar_group_state;

	int left_state;
	int right_state;

	DivideGroup(pillarNow);
	right_state = RightState(pillarNow);
	left_state = LeftState(pillarNow);

	
	//finePillar_group_state = difinePillar_group(pillarNow);  ??left?right?state

	InitPillarName();
	//????????group_finded?finePillar_group_state?????????
	switch (pillar_num)
	{
	case 1:
		printf("1 point cant work");

		break;
	case 2:
		if (left_state == -1 && right_state == 2) {
			pillard = 0;

			pillarf = 1;
		}
		if (left_state == 2 && right_state == -1) {

			pillara = 0;

			pillarc = 1;
		}
		if (left_state == 1 && right_state == -1) {
			printf("cant find");
		}
		if (left_state == -1 && right_state == 1) {
			printf("cant find");
		}
		if (left_state == 0 && right_state == 0) {
			printf("cant find");
		}

		break;
	case 3:
		if (left_state == 3) {
			pillara = 0;

			pillarb = 1;

			pillarc = 2;
		}
		if (right_state == 3) {
			pillard = 0;

			pillare = 1;

			pillarf = 2;
		}
		if (left_state == 1 && right_state == 0) {
			x1 = pol2rectX(pillarNow[0][1], pillarNow[0][0] * 0.25);
			y1 = pol2rectY(pillarNow[0][1], pillarNow[0][0] * 0.25);

			x2 = pol2rectX(pillarNow[1][1], pillarNow[1][0] * 0.25);
			y2 = pol2rectY(pillarNow[1][1], pillarNow[1][0] * 0.25);

			x3 = pol2rectX(pillarNow[2][1], pillarNow[2][0] * 0.25);
			y3 = pol2rectY(pillarNow[2][1], pillarNow[2][0] * 0.25);


			vx1 = x1 - x2;
			vy1 = y1 - y2;

			vx2 = x3 - x2;
			vy2 = y3 - y2;

			vx3 = x3 - x1;
			vy3 = y3 - y1;

			angle1 = t_angle(vx1, vy1, vx2, vy2);
			angle2 = t_angle(vx3, vy3, vx2, vy2);

			if (!(angle1 > 70 && angle1 < 110 || angle2>70 && angle2 < 110)) {
				if (t_angle(vx1, vy1, vx2, vy2) < 70) {

					pillard = 0;

					pillara = 1;

					pillarb = 2;
				}
				if (t_angle(vx1, vy1, vx2, vy2) > 110) {

					pillarf = 0;

					pillarb = 1;

					pillarc = 2;
				}
			}
			printf("cant find");
		}
		if (left_state == 1 && right_state == 0) {
			x1 = pol2rectX(pillarNow[0][1], pillarNow[0][0] * 0.25);
			y1 = pol2rectY(pillarNow[0][1], pillarNow[0][0] * 0.25);

			x2 = pol2rectX(pillarNow[1][1], pillarNow[1][0] * 0.25);
			y2 = pol2rectY(pillarNow[1][1], pillarNow[1][0] * 0.25);

			x3 = pol2rectX(pillarNow[2][1], pillarNow[2][0] * 0.25);
			y3 = pol2rectY(pillarNow[2][1], pillarNow[2][0] * 0.25);


			vx1 = x1 - x2;
			vy1 = y1 - y2;

			vx2 = x3 - x2;
			vy2 = y3 - y2;

			vx3 = x3 - x1;
			vy3 = y3 - y1;

			angle1 = t_angle(vx1, vy1, vx2, vy2);
			angle2 = t_angle(vx3, vy3, vx1, vy1);

			if (!(angle1 > 70 && angle1 < 110 || angle2>70 && angle2 < 110)) {
				if (angle1 < 70) {
					pillare = 0;

					pillarf = 1;

					pillarc = 2;
				}
				if (angle1 > 110) {
					pillard = 0;

					pillare = 1;

					pillara = 2;
				}
			}
			else {
				printf("cant find");
			}
		}
		if (left_state == 2 && right_state == 0) {
			x1 = pol2rectX(pillarNow[0][1], pillarNow[0][0] * 0.25);
			y1 = pol2rectY(pillarNow[0][1], pillarNow[0][0] * 0.25);

			x2 = pol2rectX(pillarNow[1][1], pillarNow[1][0] * 0.25);
			y2 = pol2rectY(pillarNow[1][1], pillarNow[1][0] * 0.25);

			x3 = pol2rectX(pillarNow[2][1], pillarNow[2][0] * 0.25);
			y3 = pol2rectY(pillarNow[2][1], pillarNow[2][0] * 0.25);


			vx1 = x1 - x2;
			vy1 = y1 - y2;

			vx2 = x3 - x2;
			vy2 = y3 - y2;

			vx3 = x3 - x1;
			vy3 = y3 - y1;

			angle1 = t_angle(vx1, vy1, vx2, vy2);
			angle2 = t_angle(vx3, vy3, vx2, vy2);

			if (angle1 > 70 && angle1 < 110) {
				pillarf = 0;

				pillara = 1;

				pillarc = 2;
			}

			if (angle2 > 70 && angle2 < 110) {
				pillard = 0;

				pillara = 1;

				pillarc = 2;
			}
			if (angle1 < 80) {
				pillare = 0;

				pillara = 1;

				pillarc = 2;
			}

		}
		if (left_state == 0 && right_state == 2) {
			x1 = pol2rectX(pillarNow[0][1], pillarNow[0][0] * 0.25);
			y1 = pol2rectY(pillarNow[0][1], pillarNow[0][0] * 0.25);

			x2 = pol2rectX(pillarNow[1][1], pillarNow[1][0] * 0.25);
			y2 = pol2rectY(pillarNow[1][1], pillarNow[1][0] * 0.25);

			x3 = pol2rectX(pillarNow[2][1], pillarNow[2][0] * 0.25);
			y3 = pol2rectY(pillarNow[2][1], pillarNow[2][0] * 0.25);


			vx1 = x1 - x2;
			vy1 = y1 - y2;

			vx2 = x3 - x2;
			vy2 = y3 - y2;

			vx3 = x3 - x1;
			vy3 = y3 - y1;

			angle1 = t_angle(vx1, vy1, vx2, vy2);
			angle2 = t_angle(vx3, vy3, vx1, vy1);

			if (angle1 > 70 && angle1 < 110) {
				pillard = 0;

				pillarf = 1;

				pillara = 2;
			}

			if (angle2 > 70 && angle2 < 110) {
				pillard = 0;

				pillarf = 1;

				pillarc = 2;
			}
			if (angle1 < 80) {
				pillard = 0;

				pillarf = 1;

				pillarb = 2;
			}

		}

		break;
	case 4:
		if (right_state == 3) {
			x1 = pol2rectX(pillarNow[0][1], pillarNow[0][0] * 0.25);
			y1 = pol2rectY(pillarNow[0][1], pillarNow[0][0] * 0.25);

			x2 = pol2rectX(pillarNow[1][1], pillarNow[1][0] * 0.25);
			y2 = pol2rectY(pillarNow[1][1], pillarNow[1][0] * 0.25);

			x3 = pol2rectX(pillarNow[3][1], pillarNow[2][0] * 0.25);
			y3 = pol2rectY(pillarNow[3][1], pillarNow[2][0] * 0.25);


			vx1 = x1 - x2;
			vy1 = y1 - y2;

			vx2 = x3 - x2;
			vy2 = y3 - y2;

			angle1 = t_angle(vx1, vy1, vx2, vy2);

			if (angle1 < 70) {
				pillarf = 0;

				pillare = 1;

				pillard = 2;

				pillarc = 3;
			}
			if (angle1 > 110) {
				pillarf = 0;

				pillare = 1;

				pillard = 2;

				pillara = 3;
			}
			if (angle1 < 110 && angle1 < 70) {
				pillarf = 0;

				pillare = 1;

				pillard = 2;

				pillarb = 3;
			}


		}
		if (left_state == 3) {
			x1 = pol2rectX(pillarNow[0][1], pillarNow[0][0] * 0.25);
			y1 = pol2rectY(pillarNow[0][1], pillarNow[0][0] * 0.25);

			x2 = pol2rectX(pillarNow[2][1], pillarNow[1][0] * 0.25);
			y2 = pol2rectY(pillarNow[2][1], pillarNow[1][0] * 0.25);

			x3 = pol2rectX(pillarNow[3][1], pillarNow[2][0] * 0.25);
			y3 = pol2rectY(pillarNow[3][1], pillarNow[2][0] * 0.25);


			vx1 = x1 - x2;
			vy1 = y1 - y2;

			vx2 = x3 - x2;
			vy2 = y3 - y2;

			angle1 = t_angle(vx1, vy1, vx2, vy2);

			if (angle1 < 70) {
				pillard = 0;

				pillara = 1;

				pillarb = 2;

				pillarc = 3;
			}
			if (angle1 > 110) {
				pillarf = 0;

				pillara = 1;

				pillarb = 2;

				pillarc = 3;
			}
			if (angle1 < 110 && angle1 < 70) {
				pillare = 0;

				pillara = 1;

				pillarb = 2;

				pillarc = 3;
			}


		}
		if (left_state == 2 && right_state == 2) {
			pillard = 0;

			pillarf = 1;

			pillara = 2;

			pillarc = 3;
		}
		if (left_state == 2 && right_state == 1) {
			x1 = pol2rectX(pillarNow[0][1], pillarNow[0][0] * 0.25);
			y1 = pol2rectY(pillarNow[0][1], pillarNow[0][0] * 0.25);

			x2 = pol2rectX(pillarNow[1][1], pillarNow[1][0] * 0.25);
			y2 = pol2rectY(pillarNow[1][1], pillarNow[1][0] * 0.25);

			x3 = pol2rectX(pillarNow[3][1], pillarNow[2][0] * 0.25);
			y3 = pol2rectY(pillarNow[3][1], pillarNow[2][0] * 0.25);


			vx1 = x2 - x1;
			vy1 = y2 - y1;

			vx2 = x3 - x1;
			vy2 = y3 - y1;

			angle1 = t_angle(vx1, vy1, vx2, vy2);

			if (angle1 > 70 && angle1 < 110) {
				pillard = 0;
E;
				pillare = 1;

				pillara = 2;

				pillarc = 3;
			}
			else
			{
				pillare = 0;

				pillarf = 1;

				pillara = 2;

				pillarc = 3;
			}
		}
		if (left_state == 1 && right_state == 2) {
			x1 = pol2rectX(pillarNow[0][1], pillarNow[0][0] * 0.25);
			y1 = pol2rectY(pillarNow[0][1], pillarNow[0][0] * 0.25);

			x2 = pol2rectX(pillarNow[1][1], pillarNow[1][0] * 0.25);
			y2 = pol2rectY(pillarNow[1][1], pillarNow[1][0] * 0.25);

			x3 = pol2rectX(pillarNow[3][1], pillarNow[2][0] * 0.25);
			y3 = pol2rectY(pillarNow[3][1], pillarNow[2][0] * 0.25);


			vx1 = x2 - x1;
			vy1 = y2 - y1;

			vx2 = x3 - x1;
			vy2 = y3 - y1;

			angle1 = t_angle(vx1, vy1, vx2, vy2);

			if (angle1 > 70 && angle1 < 110) {
				pillard = 0;

				pillarf = 1;

				pillarb = 2;

				pillarc = 3;
			}
			else
			{
				pillard = 0;

				pillarf = 1;

				pillara = 2;

				pillarb = 3;
			}
		}
		if (left_state == 1 && right_state == 1) {
			x1 = pol2rectX(pillarNow[0][1], pillarNow[0][0] * 0.25);
			y1 = pol2rectY(pillarNow[0][1], pillarNow[0][0] * 0.25);

			x2 = pol2rectX(pillarNow[1][1], pillarNow[1][0] * 0.25);
			y2 = pol2rectY(pillarNow[1][1], pillarNow[1][0] * 0.25);

			x3 = pol2rectX(pillarNow[3][1], pillarNow[2][0] * 0.25);
			y3 = pol2rectY(pillarNow[3][1], pillarNow[2][0] * 0.25);


			vx1 = x2 - x1;
			vy1 = y2 - y1;

			vx2 = x3 - x1;
			vy2 = y3 - y1;

			angle1 = t_angle(vx1, vy1, vx2, vy2);

			if (angle1 > 70 && angle1 < 110) {
				printf("cant find");
			}
			if (angle1 < 70) {
				pillard = 0;

				pillare = 1;

				pillara = 2;

				pillarb = 3;
			}
			if (angle1 > 110) {
				pillare = 0;

				pillarf = 1;

				pillarb = 2;

				pillarc = 3;
			}
		}
		break;
	case 5:

		if (left_state == 3 && right_state == 1) {
			x1 = pol2rectX(pillarNow[0][pLen], pillarNow[0][pIndex] * 0.25);
			y1 = pol2rectY(pillarNow[0][pLen], pillarNow[0][pIndex] * 0.25);

			x2 = pol2rectX(pillarNow[1][pLen], pillarNow[1][pIndex] * 0.25);
			y2 = pol2rectY(pillarNow[1][pLen], pillarNow[1][pIndex] * 0.25);

			x3 = pol2rectX(pillarNow[4][pLen], pillarNow[2][pIndex] * 0.25);
			y3 = pol2rectY(pillarNow[4][pLen], pillarNow[2][pIndex] * 0.25);


			vx1 = x2 - x1;
			vy1 = y2 - y1;

			vx2 = x3 - x1;
			vy2 = y3 - y1;

			angle1 = t_angle(vx1, vy1, vx2, vy2);

			if (angle1 > 70 && angle1 < 110) {
				pillard = 0;

				pillare = 1;

				pillara = 2;

				pillarb = 3;

				pillarc = 4;
			}
			else
			{
				pillare = 0;

				pillarf = 1;

				pillara = 2;

				pillarb = 3;

				pillarc = 4;
			}
		}
		if (left_state == 1 && right_state == 3) {

			x1 = pol2rectX(pillarNow[0][pLen], pillarNow[0][pIndex] * 0.25);
			y1 = pol2rectY(pillarNow[0][pLen], pillarNow[0][pIndex] * 0.25);

			x2 = pol2rectX(pillarNow[1][pLen], pillarNow[1][pIndex] * 0.25);
			y2 = pol2rectY(pillarNow[1][pLen], pillarNow[1][pIndex] * 0.25);

			x3 = pol2rectX(pillarNow[4][pLen], pillarNow[2][pIndex] * 0.25);
			y3 = pol2rectY(pillarNow[4][pLen], pillarNow[2][pIndex] * 0.25);


			vx1 = x2 - x1;
			vy1 = y2 - y1;

			vx2 = x3 - x1;
			vy2 = y3 - y1;

			angle1 = t_angle(vx1, vy1, vx2, vy2);

			if (angle1 > 70 && angle1 < 110) {
				pillard = 0;

				pillare = 1;

				pillarf = 2;

				pillarb = 3;

				pillarc = 4;
			}
			else
			{
				pillard = 0;

				pillare = 1;

				pillarf = 2;

				pillara = 3;

				pillarb = 4;
			}

		}
		if (left_state == 3 && right_state == 2) {
			pillard = 0;

			pillarf = 1;

			pillara = 2;

			pillarb = 3;

			pillarc = 4;
		}
		if (left_state == 2 && right_state == 3) {
			pillard = 0;

			pillare = 1;

			pillarf = 2;

			pillara = 3;

			pillarc = 4;
		}
		break;
	case 6:
		pillard = 0;

		pillare = 1;

		pillarf = 2;

		pillara = 3;

		pillarb = 4;

		pillarc = 5;

		break;

	default:
		break;
	}
}

	
	
	



void sePillar(float pillarNow[][5], float **pillarNew2) //ɸѡͬһֱ�ߵ�����
{
	//pillar_numҪ����4
	float pillarNew[pMax][5];
	int flag = 0;  //Ϊ1˵���ϸ�б�ʷ���Ҫ��
	int angle3, angle4;
	float xx, yy;
	float x[pMax], y[pMax];
	float vx[pMax], vy[pMax];
	float angle1, angle2;
	float delta, delta2;
	int m = 0;
	int k = 0,i,j,n;
	for (i = 0; i < pillar_num; i++) {

		x[i] = pol2rectX(pillarNow[i][dist], pillarNow[i][step] * 0.25);
		y[i] = pol2rectY(pillarNow[i][1], pillarNow[i][0] * 0.25);
	}

	printf("");


	printf("input:\n");
	for (i = 0; i < pillar_num; i++) {
		printf("%f,",x[i]);
	}

	printf("\n");

	for (i = 0; i < pillar_num; i++) {
		printf("%f,", y[i]);
	}


	for (i = 0; i < pillar_num - 3; i++) {
		printf("%d", i);
		k = 0;
		vx[k] = x[i + 1] - x[i];
		vy[k] = y[i + 1] - y[i];
		k++;
		for (j = i + 1; j < pillar_num - 2; j++) {
			for (n = j + 1; n < pillar_num; n++) {
				vx[k] = x[n] - x[j];
				vy[k] = y[n] - y[j];
				angle1 = t_angle(vx[k - 1], vy[k - 1], vx[k], vy[k]);
				printf("\n%f\n", angle1);
				if (angle1 > 70 && angle1 < 110) {
					printf("11111\n");
					k++;
					break;      
				}
			}
			if (k == 4) {
				break;
			}
		}
		if (k == 4) {
			break;
		}
	}

	if (k != 4) {
		printf("no sense");
	}

	if (k == 4) {
		delta = vx[0] / vy[0];              //�ϲ���õ�б��
		angle3 = t_angle(1, 0, vx[0], vy[0]);

		for (i = 0; i < pillar_num - 1; i++) {
			xx = x[i + 1] - x[i];         //��ÿ���������ĵ���б��
			yy = y[i + 1] - y[i];

			angle4 = t_angle(1, 0, xx, yy);
			//cout << "angle4_"<< i<< ":" << angle4 << endl;
			//delta2 = vx[k] / vy[k];
			//if (delta + 10 < delta2&&delta2 > delta - 10) {
			if (angle3 + 15 > angle4 && angle4 > angle3 - 15) {
				pillarNew[m][0] = pillarNow[i][0];
				pillarNew[m][1] = pillarNow[i][1];
				pillarNew[m][2] = pillarNow[i][2];
				pillarNew[m][3] = pillarNow[i][3];
				pillarNew[m][4] = pillarNow[i][4];
				m++;
				flag = 1;
				continue;
			}
			if (flag == 1) {
				flag = 0;
				pillarNew[m][0] = pillarNow[i][0];
				pillarNew[m][1] = pillarNow[i][1];
				pillarNew[m][2] = pillarNow[i][2];
				pillarNew[m][3] = pillarNow[i][3];
				pillarNew[m][4] = pillarNow[i][4];
				m++;
				continue;
			}
		}
		if (i == pillar_num - 2 && flag == 1) {
			i++;
			pillarNew[m][0] = pillarNow[i][0];
			pillarNew[m][1] = pillarNow[i][1];
			pillarNew[m][2] = pillarNow[i][2];
			pillarNew[m][3] = pillarNow[i][3];
			pillarNew[m][4] = pillarNow[i][4];
			m++;
		}
	}
	pillar_num = m;
	printf("output:\n");
	for (i = 0; i < m; i++) {
		printf("%f,", pillarNew[i][step]);
	}
	printf("\n");
	for (i = 0; i < m; i++) {
		printf("%f,", pillarNew[i][dist]);
	}

	printf("\n");

}


//�ҵ�����һ�ߵ����ӣ�ͬʱ�ҵ�������һ����ͬб�ʵ�����
void findLinePillar(float pillar[][5], float **new_pillar) {


	int flag[pMax] = { 0 }; //0Ϊδ���� ����ͬһ������ͬһ�ߣ�-1Ϊ��Ч����
	int i = 0, j = 0, k = 0;
	float x[pMax], y[pMax];	
	float vx1, vy1;
	float vx2, vy2;
	float vx, vy;
	float angle1, angle2;
	float len = 0;
	int m = 1;
	int n = pillar_num;
	int mm = 0;


	for (i = 0; i < pillar_num; i++) {
		x[i] = pol2rectX(pillar[i][1], pillar[i][0] * 0.25);
		y[i] = pol2rectY(pillar[i][1], pillar[i][0] * 0.25);
	}

	//�ҳ����������ĵ�
	for (i = 0; i < pillar_num; i++) {
		if (flag[i] != 0) {
			continue;
		}
		for (j = i + 1; j < pillar_num - 1; j++) {
			if (flag[i] != 0) {
				break;
			}
			if (flag[j] != 0) {
				continue;
			}
			vx1 = x[j] - x[i];
			vy1 = y[j] - y[i];
			
			for (k = j + 1; k < pillar_num; k++) {
				if (flag[k] != 0) {
					continue;
				}
				vx2 = x[k] - x[i];
				vy2 = y[k] - y[i];
				angle2 = t_angle(vx1, vy1, vx2, vy2);
				if ( 4 > angle2 && angle2 > -4 && take_distance(x[i],y[i],x[j],y[j])>1440 && take_distance(x[k], y[k], x[j], y[j]) > 1440 && take_distance(x[i], y[i], x[j], y[j]) < 1855 && take_distance(x[k], y[k], x[j], y[j]) < 1855) {
					vx = vx1, vy = vy1;
					flag[i] = m;
					flag[j] = m;
					flag[k] = m;
					m++;
					break;
				}
			}
		}
	}

	//���ڵ�ȥ��
	for (i = 0; i < pillar_num; i++) {
		if (flag[i] != 0) {
			continue;
		}
		for (j = 0; j < pillar_num; j++) {
			if (j == i) {
				continue;
			}
			len = t_len(x[j] - x[i], y[j] - y[i]);
			if (len < 1000 && flag[j] != 0) {
				flag[i] = -1;
				break;
			}
		}
	}

	if (m == 2) {
		for (i = 0; i < pillar_num; i++) {
			if (flag[i] != 0) {
				continue;
			}
			for (j = 0; j < pillar_num; j++) {
				if (i == j) {
					continue;
				}
				if (flag[j] != 0) {
					continue;
				}

				vx2 = x[j] - x[i];
				vy2 = y[j] - y[i];
				angle2 = t_angle(vx, vy, vx2, vy2);
				if (4 > angle2 && angle2 > -4 && take_distance(x[i], y[i], x[j], y[j]) > 1000) {
					flag[i] = m;
					flag[j] = m;
					m++;
					break;
				}

			}
		}
	}


	for (m = 0; m < n; m++) {
		if (flag[m] <= 0) {
			pillar_num--;
		}
		else {
			new_pillar[mm][0] = pillar[m][0];
			new_pillar[mm][1] = pillar[m][1];
			new_pillar[mm][2] = pillar[m][2];
			new_pillar[mm][3] = pillar[m][3];
			new_pillar[mm][4] = pillar[m][4];
			mm++;
		}
	}

}







/************************
				���ִ���
************************/
void classification(float **pillar)
{
	void robot_location_3pitchroll_down(float **pillar,int b,int c,int d,int c_y);
	void robot_location_3pitchroll_up(float **pillar,int b,int c,int d,int c_y);
	void robot_location_2pitch(float **pillar,int b,int c,int c_y);
	void robot_location_2roll(float **pillar,int b,int e,int b_y);
	printf("a:%d,b:%d,c:%d,d:%d,e:%d,f:%d\r\n",pillara,pillarb,pillarc,pillard,pillare,pillarf);
	if((pillarb!=-1)&&(pillarc!=-1)&&(pillard!=-1))
	{
		pillar[pillarb][dist] +=30;
		pillar[pillarc][dist] +=30;
		pillar[pillard][dist] +=30;
		robot_location_3pitchroll_down(pillar,pillarb,pillarc,pillard,5000);
	}
	if((pillarb!=-1)&&(pillarc!=-1)&&(pillare!=-1)&&(pillard==-1))
	{
		pillar[pillarb][dist] +=30;
		pillar[pillarc][dist] +=30;
		pillar[pillare][dist] +=30;
		robot_location_3pitchroll_up(pillar,pillarb,pillarc,pillare,5000);
	}
	if((pillara!=-1)&&(pillarb!=-1)&&(pillare!=-1)&&(pillarc==-1))
	{
		pillar[pillarb][dist] +=30;
		pillar[pillara][dist] +=30;
		pillar[pillare][dist] +=30;
		robot_location_3pitchroll_down(pillar,pillara,pillarb,pillare,3500);
	}
	if((pillara!=-1)&&(pillarb!=-1)&&(pillarf!=-1)&&(pillarc==-1)&&(pillare==-1))
	{
		pillar[pillarb][dist] +=30;
		pillar[pillara][dist] +=30;
		pillar[pillarf][dist] +=30;
		robot_location_3pitchroll_up(pillar,pillara,pillarb,pillarf,3500);
	}
	if(pillarb==-1)
	{
		if((pillara==-1)&&(pillarc!=-1)&&(pillard!=-1))
		{
		    pillar[pillarc][dist] +=30;
		    pillar[pillard][dist] +=30;
			robot_location_2roll(pillar,pillarc,pillard,5000);
		}
		if((pillara!=-1)&&(pillarf!=-1)&&(pillarc==-1))
		{
			pillar[pillara][dist] +=30;
		    pillar[pillarf][dist] +=30;
			robot_location_2roll(pillar,pillara,pillarf,2000);
		}
	}
	if((pillara==-1)&&(pillarc==-1)&&(pillarb!=-1)&&(pillare!=-1))
	{
		pillar[pillarb][dist] +=30;
		pillar[pillare][dist] +=30;
		robot_location_2roll(pillar,pillarb,pillare,3500);
	}
	if((pillara==-1)&&(pillare==-1)&&(pillard==-1)&&(pillarb!=-1)&&(pillarc!=-1))
	{
		pillar[pillarb][dist] +=30;
		pillar[pillarc][dist] +=30;
		robot_location_2pitch(pillar,pillarb,pillarc,5000);
	}
	if((pillarc==-1)&&(pillarf==-1)&&(pillare==-1)&&(pillara!=-1)&&(pillarb!=-1))
	{
		pillar[pillara][dist] +=30;
		pillar[pillarb][dist] +=30;
		robot_location_2pitch(pillar,pillara,pillarb,3500);
	}
}



void robot_location_3pitchroll_down(float **pillar, int b, int c, int d, int c_y) //e.g. b=pillara,c=pillarb,d=pillare
	// int c_y��Ϊc����y����,��λΪmm,���c=c,b_y=5000;if c=b,b_y=3500;if c=a,b_y=2000;
{
	/*
	b
	c         Radar                d
	*/
	float Anglebc = Abs((pillar[b][step] - pillar[c][step]))*0.25;
	float Anglecd = Abs((pillar[c][step] - pillar[d][step]))*0.25;
	float Angleb540 = (pillar[b][step] - 540)*0.25;
	float CD, BC, cos_pitch, CH, real_CH, cos_roll, yaw, b1;        //BE,BC==���Ӽ��õľ��룬H=����,real_CH=����C�ľ���,b1=ȥ��roll֮���b
	float cosC, cosB;                              //��ʵ�н�
	BC = sqrt(pow(pillar[b][dist], 2) + pow(pillar[c][dist], 2) - 2 * (pillar[b][dist])*(pillar[c][dist])*cos(Anglebc*PI / 180));
	CD = sqrt(pow(pillar[c][dist], 2) + pow(pillar[d][dist], 2) - 2 * (pillar[c][dist])*(pillar[d][dist])*cos(Anglecd*PI / 180));
	//�������Ӽ��õľ���
	cosC = ((float)pow(BC, 2) + (float)pow(pillar[c][dist], 2) - (float)pow(pillar[b][dist], 2)) / (float)(2 * pillar[c][dist] * BC);
	cosB = ((float)pow(BC, 2) + (float)pow(pillar[b][dist], 2) - (float)pow(pillar[c][dist], 2)) / (float)(2 * pillar[b][dist] * BC);
	cos_pitch = (1500 / BC);
	cos_roll = (10850 / CD);
	CH = pillar[c][dist] * cosC;

	real_CH = CH * cos_pitch;

	mr2_x[0] = (pillar[b][dist] * pillar[c][dist] * sin(Anglebc*PI / 180) / BC)*cos_roll + 1225;

	mr2_coordinate_x = mr2_x[0];


	mr2_y[0] = c_y - real_CH;

	mr2_coordinate_y = mr2_y[0];

	yaw = (acos(cosB)) * 180 / PI - Angleb540;  //�Ƕ���yaw(ƫ��)
	printf("�״��x����:%f\n�״��y����:%f\n\n ƫ��yaw:%f\n", mr2_coordinate_x, mr2_coordinate_y, yaw);
}


void robot_location_3pitchroll_up(float **pillar,int b,int c,int d,int c_y) //e.g. b=pillara,c=pillarb,d=pillare
	// int c_y��Ϊc����y����,��λΪmm,���c=c,b_y=5000;if c=b,b_y=3500;if c=a,b_y=2000;
{
	/*
	b                              d
	c         Radar                
	*/
    float Anglebc = Abs((pillar[b][step] - pillar[c][step]))*0.25;
	float Anglebd = Abs((pillar[b][step] - pillar[d][step]))*0.25;
	float Angleb540 = (pillar[b][step] - 540)*0.25;
	float BD,BC,cos_pitch,CH,real_CH,cos_roll,yaw;        //BE,BC==���Ӽ��õľ��룬H=����,real_CH=����C�ľ���,
	                                                      //yaw>0,��ƫ��yaw<0,��ƫ
	float cosC,cosB;                              //��ʵ�н�
	BC=sqrt(pow(pillar[b][dist],2)+pow(pillar[c][dist],2)-2*(pillar[b][dist])*(pillar[c][dist])*cos(Anglebc*PI/180));
	BD=sqrt(pow(pillar[b][dist],2)+pow(pillar[d][dist],2)-2*(pillar[b][dist])*(pillar[d][dist])*cos(Anglebd*PI/180));
	//�������Ӽ��õľ���
	cosC=((float)pow(BC,2)+(float)pow(pillar[c][dist],2)-(float)pow(pillar[b][dist],2))/(float)(2*pillar[c][dist]*BC);
	cosB=((float)pow(BC,2)+(float)pow(pillar[b][dist],2)-(float)pow(pillar[c][dist],2))/(float)(2*pillar[b][dist]*BC);
	cos_pitch=(1500/BC);
	cos_roll=(10850/BD);
	CH=pillar[c][dist]*cosC;

	real_CH=CH*cos_pitch;

	mr2_x[0] =(pillar[b][dist] * pillar[c][dist] *sin(Anglebc*PI/180) /BC)*cos_roll +1225;

	mr2_coordinate_x = mr2_x[0];


	mr2_y[0] = c_y-real_CH;

	mr2_coordinate_y=mr2_y[0];
	//����ƫ����
	//�����ӵ�����Ӽ�����ת�����״���������ϵ�µ�xֵ
	//	float pillar_yaw[7] = { 0 };//ǰ�����Ǹ���ABCDEF����ƫ��ǣ����߸�����ʹ���ļ�������������ƫ���
	//	float pillar_lidar_x[7] = { 0 };//�����������ӵ�x����
	//	int ab = 0;
	//	pillar_lidar_x[pillara] = pillar[pillara][dist] * cos(pillar[pillara][step] * 0.125 - 45);
	//	pillar_lidar_x[pillarb] = pillar[pillarb][dist] * cos(pillar[pillarb][step] * 0.125 - 45);
	//	pillar_lidar_x[pillarc] = pillar[pillarc][dist] * cos(pillar[pillarc][step] * 0.125 - 45);
	//	if ((pillar_lidar_x[pillara] - pillar_lidar_x[pillarb] > 5) | (pillar_lidar_x[pillara] - pillar_lidar_x[pillarb] < 5))//A��x����-B��x����=0+-5�Ļ�����Ϊ��ƫ����Ϊ0
	//		pillar_yaw[ab] = 0;
	yaw=acos(cosB)*180/PI-Angleb540;  //�Ƕ���yaw(ƫ��)
	printf("�״��x����:%f\n�״��y����:%f\n\n ƫ��yaw:%f\n", mr2_coordinate_x, mr2_coordinate_y,yaw);

}

void robot_location_2pitch(float **pillar,int b,int c,int c_y)    
	//e.g. b=pillara,c=pillarb
	// int c_y��Ϊc����y����,��λΪmm,���c=c,b_y=5000;if c=b,b_y=3500;if c=a,b_y=2000;
{
	/*
	b
	c       Radar      
	*/
	float Anglebc = Abs((pillar[b][step] - pillar[c][step]))*0.25;
	float Angleb540 = (pillar[b][step] - 540)*0.25;
	float BC,cos_pitch,CH,real_CH,yaw;        //BE,BC==���Ӽ��õľ��룬H=����,real_CH=����C�ľ���
	float cosC,cosB;                              //��ʵ�н�
	BC=sqrt(pow(pillar[b][dist],2)+pow(pillar[c][dist],2)-2*(pillar[b][dist])*(pillar[c][dist])*cos(Anglebc*PI/180));

	//�������Ӽ��õľ���
	cosC=((float)pow(BC,2)+(float)pow(pillar[c][dist],2)-(float)pow(pillar[b][dist],2))/(float)(2*pillar[c][dist]*BC);
	cosB=((float)pow(BC,2)+(float)pow(pillar[b][dist],2)-(float)pow(pillar[c][dist],2))/(float)(2*pillar[b][dist]*BC);
	cos_pitch=(1500/BC);
	CH=pillar[c][dist]*cosC;

	real_CH=CH*cos_pitch;

	mr2_x[0] =sqrt(pow(pillar[c][dist],2)-pow(CH,2)) +1225;
	/*mr2_x[1] = pillar[pillarb][dist] * pillar[pillarc][dist] * (sin(Anglebc)) / 1500 + 1000;//����B C��������MR2��Xֵ��
	mr2_x[2] = pillar[pillara][dist] * pillar[pillarc][dist] * (sin(Angleac))   / 1500 + 1000;//����A C��������MR2��Xֵ��
	mr2_coordinate[x] = (mr2_x[0] + mr2_x[1] + mr2_x[2]) / 3;
	mr2_coordinate_x = mr2_coordinate[x];*/ 
	mr2_coordinate_x = mr2_x[0];


	mr2_y[0] = c_y-real_CH;
	/*mr2_y[1] = pillar[pillarb][dist] * pillar[pillarc][dist] * (cos(Anglebc)) / 1500 + 1000;//����B C��������MR2��yֵ��
	mr2_y[2] = pillar[pillara][dist] * pillar[pillarc][dist] * (cos(Angleac)) / 1500 + 1000;//����A C��������MR2��yֵ��
	mr2_coordinate[y] = (mr2_y[0] + mr2_y[1] + mr2_y[2]) / 3;
	mr2_coordinate_y =mr2_coordinate[y];*/
	mr2_coordinate_y=mr2_y[0];
	//����ƫ����
	//�����ӵ�����Ӽ�����ת�����״���������ϵ�µ�xֵ
	//	float pillar_yaw[7] = { 0 };//ǰ�����Ǹ���ABCDEF����ƫ��ǣ����߸�����ʹ���ļ�������������ƫ���
	//	float pillar_lidar_x[7] = { 0 };//�����������ӵ�x����
	//	int ab = 0;
	//	pillar_lidar_x[pillara] = pillar[pillara][dist] * cos(pillar[pillara][step] * 0.125 - 45);
	//	pillar_lidar_x[pillarb] = pillar[pillarb][dist] * cos(pillar[pillarb][step] * 0.125 - 45);
	//	pillar_lidar_x[pillarc] = pillar[pillarc][dist] * cos(pillar[pillarc][step] * 0.125 - 45);
	//	if ((pillar_lidar_x[pillara] - pillar_lidar_x[pillarb] > 5) | (pillar_lidar_x[pillara] - pillar_lidar_x[pillarb] < 5))//A��x����-B��x����=0+-5�Ļ�����Ϊ��ƫ����Ϊ0
	//		pillar_yaw[ab] = 0;
	yaw=acos(cosB)*180/PI-Angleb540;  //�Ƕ���yaw(ƫ��)
	printf("�״��x����:%f\n�״��y����:%f\n\n ƫ��yaw:%f/n ", mr2_coordinate_x, mr2_coordinate_y,yaw);

}  

void robot_location_2roll(float **pillar,int b,int e,int b_y)      
{
	//��������ŵ������������ӣ��ڴ˺�����һ������Ϊb��һ��Ϊe,����ʾ��ͼ��ʾ
	//int b_y��Ϊb����y����,��λΪmm,���b=c,b_y=5000;if b=b,b_y=3500;if b=a,b_y=2000;
	/*                               
	b         Radar                e
	*/
	float Anglebe = Abs((pillar[b][step] - pillar[e][step]))*0.25;
	float Anglee540 = (pillar[e][step] - 540)*0.25;
	float BE,BC,cos_pitch,CH,real_BH,cos_roll,yaw,BH;        //BE,BC==���Ӽ��õľ��룬H=����,real_CH=����C�ľ���
	float cosE,cosB;                              //��ʵ�н�
	BE=sqrt(pow(pillar[pillarb][dist],2)+pow(pillar[pillare][dist],2)-2*(pillar[pillarb][dist])*(pillar[pillare][dist])*cos(Anglebe*PI/180));
	//�������Ӽ��õľ���
	cosE=((float)pow(BE,2)+(float)pow(pillar[e][dist],2)-(float)pow(pillar[b][dist],2))/(float)(2*pillar[e][dist]*BE);
	cosB=((float)pow(BE,2)+(float)pow(pillar[b][dist],2)-(float)pow(pillar[e][dist],2))/(float)(2*pillar[b][dist]*BE);
	cos_roll=(10850/BE);
	BH=pillar[b][dist]*cosB;

	real_BH=BH*cos_roll;

	mr2_x[0] =real_BH+1000;
	/*mr2_x[1] = pillar[pillarb][dist] * pillar[pillarc][dist] * (sin(Anglebc)) / 1500 + 1000;//����B C��������MR2��Xֵ��
	mr2_x[2] = pillar[pillara][dist] * pillar[pillarc][dist] * (sin(Angleac))   / 1500 + 1000;//����A C��������MR2��Xֵ��
	mr2_coordinate[x] = (mr2_x[0] + mr2_x[1] + mr2_x[2]) / 3;
	mr2_coordinate_x = mr2_coordinate[x];*/ 
	mr2_coordinate_x = mr2_x[0];

	if(Anglebe<180)
	{
		mr2_y[0] = b_y+(pillar[b][dist] * pillar[e][dist] *sin(Anglebe*PI/180) / 10850) ;
	}
	else
	{
		mr2_y[0] =b_y-(pillar[b][dist] * pillar[e][dist] *sin(Anglebe*PI/180) / 10850) ;
	}
	/*mr2_y[1] = pillar[pillarb][dist] * pillar[pillarc][dist] * (cos(Anglebc)) / 1500 + 1000;//����B C��������MR2��yֵ��
	mr2_y[2] = pillar[pillara][dist] * pillar[pillarc][dist] * (cos(Angleac)) / 1500 + 1000;//����A C��������MR2��yֵ��
	mr2_coordinate[y] = (mr2_y[0] + mr2_y[1] + mr2_y[2]) / 3;
	mr2_coordinate_y =mr2_coordinate[y];*/
	mr2_coordinate_y=mr2_y[0];
	//����ƫ����
	//�����ӵ�����Ӽ�����ת�����״���������ϵ�µ�xֵ
	//	float pillar_yaw[7] = { 0 };//ǰ�����Ǹ���ABCDEF����ƫ��ǣ����߸�����ʹ���ļ�������������ƫ���
	//	float pillar_lidar_x[7] = { 0 };//�����������ӵ�x����
	//	int ab = 0;
	//	pillar_lidar_x[pillara] = pillar[pillara][dist] * cos(pillar[pillara][step] * 0.125 - 45);
	//	pillar_lidar_x[pillarb] = pillar[pillarb][dist] * cos(pillar[pillarb][step] * 0.125 - 45);
	//	pillar_lidar_x[pillarc] = pillar[pillarc][dist] * cos(pillar[pillarc][step] * 0.125 - 45);
	//	if ((pillar_lidar_x[pillara] - pillar_lidar_x[pillarb] > 5) | (pillar_lidar_x[pillara] - pillar_lidar_x[pillarb] < 5))//A��x����-B��x����=0+-5�Ļ�����Ϊ��ƫ����Ϊ0
	//		pillar_yaw[ab] = 0;
	yaw=acos(cosE)*180/PI-Anglee540+90;  //�Ƕ���yaw(ƫ��)
	printf("�״��x����:%f\n�״��y����:%f\n\n ƫ��yaw:%f/n", mr2_coordinate_x, mr2_coordinate_y,yaw);

}