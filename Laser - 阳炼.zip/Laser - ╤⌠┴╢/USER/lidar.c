#include "sys.h"
#include "tcp_client_demo.h"
#include "delay.h"
#include "math.h"
#include "string.h"
//#include "can1.h"
#include "lidar.h"
#include "led.h"
#include "malloc.h"


#define PI 3.1415926


typedef unsigned char uchar;




int ALL_STEP = 1080;//�״�step��
int block_step = 0, block_dist = 1, block_widt = 2;//����ĵ�һ��������¼�ϰ����step���ڶ���������¼���룬������������¼����






int block_num = 0;//������¼�ϰ��������

float center_x[]={0.0f};
float center_y[]={0.0f};
float	radius[]={0.0f};

int min_distance[]={0};
float min_angle[]={0};
extern u8 recieve[TCP_CLIENT_RX_BUFSIZE];//��tcp_client_demo.c�����������飬���ڴ���״﷢�͹������ַ�������
//extern int Distance[1200];//���ڴ�Ž����ľ������ݣ���λ��mm
u16 distancelen = 0;//

float Abs(float a)
{
	if(a<0)
		return -a;
	return a;
}

 int Laser_data[5][45];
 float angle_data[5][45];
int n;
int N;
void radar_calculate(uchar*tcp_client_recvbuf,u32 *Distance)
{
    u16 i=23,j=1;
    u32 distance1,distance2,distance3;
    int index=0;
    if(tcp_client_recvbuf[0]=='G'&&tcp_client_recvbuf[1]=='D')
    {
        for(i=23;i<=3368;i+=3)    //100->333
        {
            if((i-21)%66!=0)
            { distance1=tcp_client_recvbuf[i]-48; //printf("�����Ӧ��ASCII�룺%c",tcp_client_recvbuf[i]);
            }
          else
            { distance1=tcp_client_recvbuf[i+2]-48;  //printf("%c",tcp_client_recvbuf[i+2]);
            i+=2; }
            if((i+1-21)%66!=0)
            { distance2=tcp_client_recvbuf[i+1]-48; //printf("%c",tcp_client_recvbuf[i+1]);
            }
          else
            { distance2=tcp_client_recvbuf[i+3]-48;//printf("%c",tcp_client_recvbuf[i+3]);
            i+=2;}
            if((i+2-21)%66!=0)
            {distance3=tcp_client_recvbuf[i+2]-48; //printf("%c\r\n",tcp_client_recvbuf[i+2]);
            }
          else
            { distance3=tcp_client_recvbuf[i+4]-48; //printf("%c\r\n",tcp_client_recvbuf[i+4]);
            i+=2; }
            Distance[index]=distance1*4096+distance2*64+distance3;//mm
            //angle[index]=0.25*(j-1);
            index++;
            j++;
        }
    }
}








//��¼�����ϰ������״�����λ��



void block_record(u32 *Distance,float **block_mid )
{    
     double p = 0.25*3.14159265359/180.0;
	//����ѭ���ͼ�¼pillar����Ŀ
	volatile int flag = 0;//�����ж������Ƿ��¼��ȫ��1Ϊ�жϼ�¼��ȫ
	int block_min = 0, block_max = 0;//��¼�ϰ������ʼstep��
    int	i = 1;
	block_num=0;
	for (i = 314; i < ALL_STEP-314; i++)  
	{   

		
		if(Abs(Distance[i-1]-Distance[i])>8000)
	  {
		if (Distance[i] < 4000)//ɸѡ6m�ڵ��ϰ���
		{
			block_min = i, block_max = i;
			flag = 0;

			for (flag = 0; flag == 0; i++)//�������ӵĿ���
			{
				if ( Abs((int)(Distance[i+1] - (int)Distance[i])) < (30) )//�˴�����������Ӧ��ԶС��pillar_wid����Ϊ��������step֮���Ǿ��벻���ܴﵽpillar_wid
				{   
					
					block_max = i+1;
					Laser_data[block_num][n]=(int)Distance[i];
					printf("%d\r\t",Laser_data[block_num][n]);
					angle_data[block_num][n]=i*p;
					//printf("obstacle_angle%d:%fPI\r\t",block_num,angle_data[block_num][n]);
					n++;
					
					if(Abs((int)(Distance[i+2]-(int)Distance[i+1])) > (6000)) //�������ı���ֵ
					{ 	
							           block_num++;
					                    n=0;
					                    flag=1;
						/*
						if(n<45)
						{ 

							for(int k=0;k<n;k++)
							{           //double x,y=0.0f;
								        
								        x = Laser_data[block_num][k]*cos(angle_data[block_num][n]-PI/4);
                                        y = Laser_data[block_num][k]*sin(angle_data[block_num][n]-PI/4);
                                       							printf("x:%f y:%f \r\n",x,y);								
								
							double a,b,c,d,e,f=0.0f;
							double x1=0.0f,x2=0.0f,x3=0.0f;
							double y1=0.0f,y2=0.0f,y3=0.0f;
							double x,y=0.0f;
                             x1=Laser_data[block_num][k]*cos(angle_data[block_num][n]-PI/4);
							 x2=Laser_data[block_num][k+1]*cos(angle_data[block_num][n]-PI/4);
						     x3=Laser_data[block_num][k+2]*cos(angle_data[block_num][n]-PI/4);
						     y1=Laser_data[block_num][k]*sin(angle_data[block_num][n]-PI/4);
						     y2=Laser_data[block_num][k+1]*sin(angle_data[block_num][n]-PI/4);
						     y3=Laser_data[block_num][k+2]*sin(angle_data[block_num][n]-PI/4);
								printf("x1:%f x2:%f x3:%f\r\n",x1,x2,x3);
								printf("y1:%f y2:%f y3:%f\r\n",y1,y2,y3);
						     a=(y1+y2)/2;
							 b=(x2-x1)/(y1-y2);
							 c=(x1+x2)/2;
							 d=(y2+y3)/2;
							 e=(x3-x2)/(y2-y3);
							 f=(x2+x3)/2;
							 x=(d-a+b*c-e*f)/(b-e);
						     y=b*(x-c)+a;
						     center_y[block_num]+=y/(n-2);
							 center_x[block_num]+=x/(n-2);
							}
										block_num++;
					                    n=0;
					                    flag=1;
							printf("��%d������Բ�ģ�x:%f y:%f\r\n",center_x[block_num], center_y[block_num]);*/
						}
					/*
						else	
						  n=0;
					     flag=1;*/
											
						/*
						if(n<45)
						{							
						 min_distance[block_num]=Laser_data[block_num][n];
						for(int l=0;l<n;l++)
						{  
							if(min_distance[block_num]>Laser_data[block_num][l])
							{  min_distance[block_num]=Laser_data[block_num][l];
							   min_angle[block_num]= angle_data[block_num][l];
								//printf("%f",angle_data[block_num][l])
							}
							//printf("%f",angle_data[block_num][l]);
						}
						/* 
						printf("��%d�����Ӿ��룺%d\r\n",block_num+1,min_distance[block_num]);
						printf("��%d�����ӽǶȣ�%f\r\n",block_num+1,min_angle[block_num]);	
											     block_num++;
					                                 n=0;
					                                 flag=1;
					    }
						else
						{ 
							n=0;
						 	flag=1;
						}
							
								
							
						/*
						//��С���˷���ʱ�����ã�Ч��̫��
						if(n>20)
						{
     	 float x = 0.0f, y = 0.0f, x2 = 0.0f, y2 =0.0f,  C, D, E, G, H;
         float a, b, c;
	     float sum_x = 0.0f, sum_y =0.0f;
         float sum_x2 = 0.0f, sum_y2 = 0.0f;
         float sum_x3 = 0.0f, sum_y3 = 0.0f;
         float sum_xy = 0.0f, sum_x1y2 =0.0f, sum_x2y1 = 0.0f;						
     for (int k = 0; k < n; k++)
     {
          x = Laser_data[block_num][k]*cos(angle_data[block_num][n]-PI/4);
          y = Laser_data[block_num][k]*sin(angle_data[block_num][n]-PI/4);
          x2 = x * x;
          y2 = y * y;
         sum_x += x;
         sum_y += y;
         sum_x2 += x2;
         sum_y2 += y2;
         sum_x3 += x2 * x;
         sum_y3 += y2 * y;
         sum_xy += x * y;
         sum_x1y2 += x * y2;
         sum_x2y1 += x2 * y;
     }
	 N=n;
     C = N * sum_x2 - sum_x * sum_x;
     D = N * sum_xy - sum_x * sum_y;
     E = N * sum_x3 + N * sum_x1y2 - (sum_x2 + sum_y2) * sum_x;
     G = N * sum_y2 - sum_y * sum_y;
     H = N * sum_x2y1 + N * sum_y3 - (sum_x2 + sum_y2) * sum_y;
     a = (H * D - E * G) / (C * G - D * D);
     b = (H * C - E * D) / (D * D - G * C);
     c = -(a * sum_x + b * sum_y + sum_x2 + sum_y2) / N;

     center_x[block_num] = a / (-2);
     center_y[block_num] = b / (-2);
     radius[block_num] = sqrt(a * a + b * b - 4 * c) / 2;
     printf("��%d��ԲԲ�����꣺x:%f y:%f\r\n",block_num,center_x[block_num],center_y[block_num]);	
 }	*/               
              

				    
			   }
		   }
	   } 
	}
   }

	printf("ʮ������%d��Բ��\r\n", block_num);
}


/**
 * ��С���˷����Բ
 * ��ϳ���Բ��Բ������Ͱ뾶����ʽ��ʾ
 */
/*
void circleLeastFit()
{
     center_x = 0.0f;
     center_y = 0.0f;
     radius = 0.0f;
     if (< 3)
     {
         return false;
     }

     double sum_x = 0.0f, sum_y = 0.0f;
     double sum_x2 = 0.0f, sum_y2 = 0.0f;
     double sum_x3 = 0.0f, sum_y3 = 0.0f;
     double sum_xy = 0.0f, sum_x1y2 = 0.0f, sum_x2y1 = 0.0f;

     int N = points.size();
     for (int i = 0; i < N; i++)
     {
         double x = points[i].real();
         double y = points[i].imag();
         double x2 = x * x;
         double y2 = y * y;
         sum_x += x;
         sum_y += y;
         sum_x2 += x2;
         sum_y2 += y2;
         sum_x3 += x2 * x;
         sum_y3 += y2 * y;
         sum_xy += x * y;
         sum_x1y2 += x * y2;
         sum_x2y1 += x2 * y;
     }

     double C, D, E, G, H;
     double a, b, c;

     C = N * sum_x2 - sum_x * sum_x;
     D = N * sum_xy - sum_x * sum_y;
     E = N * sum_x3 + N * sum_x1y2 - (sum_x2 + sum_y2) * sum_x;
     G = N * sum_y2 - sum_y * sum_y;
     H = N * sum_x2y1 + N * sum_y3 - (sum_x2 + sum_y2) * sum_y;
     a = (H * D - E * G) / (C * G - D * D);
     b = (H * C - E * D) / (D * D - G * C);
     c = -(a * sum_x + b * sum_y + sum_x2 + sum_y2) / N;

     center_x = a / (-2);
     center_y = b / (-2);
     radius = sqrt(a * a + b * b - 4 * c) / 2;
 
}

/*houghԲ�任
int HoughArc(int X[] , int Y[] , int Cnt ,int r, ArcPara * Arc){
	vector<iPoint>center;
	vector<int>VoteCnt;
	double theta;
	int a,b;
	int minA,maxA,minB,maxB;
	int VotedFlag = 0;
	double deltaTheta = PI/180;//���1��
	double startAngle = 150.0*PI/180;
	double endAngle = PI*2 + PI/6;
	center.clear();
	VoteCnt.clear();
	minA = maxA = X[0] - r;
	minB = maxB = X[0]; //theta = 0
	//����a��b����С�����ֵ
	for (int i = 0; i < Cnt;i++)
	{
		for (theta = startAngle; theta < endAngle;theta += deltaTheta)
		{
			a = (int)(X[i] - r*cos(theta) + 0.5);
			b = (int)(Y[i] - r*sin(theta) + 0.5);
			if (a > maxA)
			{
				maxA = a;
			}else if (a < minA)
			{
				minA = a;
			}
 
			if (b > maxB)
			{
				maxB = b;
			}else if (b < minB)
			{
				minB = b;
			}
 
		}
	}
	//ȷ��a��b�ķ�Χ֮�󣬼�ȷ����Ʊ��Ĵ�С
	int aScale = maxA - minA + 1;
	int bScale = maxB - minB + 1;
 
	int *VoteBox = new int[aScale*bScale];
	//VoteBox��ʼ��Ϊ0
	for (int i = 0; i < aScale*bScale;i++)
	{
		VoteBox[i] = 0;
	}
	//��ʼͶƱ
	for (int i = 0; i < Cnt;i++)
	{
		//printf("%d  ",i);
		for (theta = startAngle; theta < endAngle;theta += deltaTheta)
		{
 
			a = (int)(X[i] - r*cos(theta) + 0.5);
			b = (int)(Y[i] - r*sin(theta) + 0.5);	
			VoteBox[(b - minB)*aScale + a - minA] = VoteBox[(b - minB)*aScale + a - minA] + 1;
		}
	}
 
	//ɸѡƱ��
	int VoteMax = 0;
	int VoteMaxX,VoteMaxY;
	for (int i = 0; i < bScale ;i++)
	{
		for (int j = 0; j < aScale ;j++)
		{
			if (VoteBox[i*aScale + j] > VoteMax)
			{
				VoteMax = VoteBox[i*aScale + j];
				VoteMaxY = i;
				VoteMaxX = j;
			}
		}
	}
	
	int Count = 0;
	printf("VoteMax: %d",VoteMax);
	for (int i = 0; i < bScale ;i++)
	{
		for (int j = 0; j < aScale ;j++)
		{
			if (VoteBox[i*aScale + j] >= VoteMax)
			{
				Count++;
			}
		}
	}
	printf("   %d \n",Count);
	//�ͷ��ڴ�
	delete [] VoteBox;
	if (VoteMax > 3)
	{
		Arc->center.x = VoteMaxX + minA;
		Arc->center.y = VoteMaxY + minB;
		Arc->r = r;
		return 1;
	}else {
		return 0;
	}
	return 1;
}

*/











